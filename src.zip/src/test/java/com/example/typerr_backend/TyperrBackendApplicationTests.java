package com.example.typerr_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TyperrBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
